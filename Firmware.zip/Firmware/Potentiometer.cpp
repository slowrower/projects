#include "Potentiometer.h"

Potentiometer::Potentiometer(int pin) : AnalogReader(pin) {}



